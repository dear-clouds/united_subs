<?php
/**
 * AJDE frontend supporters
 *
 * @version 0.1
 * @updated 2015-12
 */

if(class_exists('ajde_frontend')) return;

class ajde_frontend{

}
<?php
/*
Plugin Name: Bounce Plugin
Plugin URI: http://themeforest.net/item/bounce-professional-wordpress-buddypress-theme/2324726?ref=GhostPool
Description: A required plugin for the Bounce theme you purchased from ThemeForest. It includes a number of features that you can still use if you switch to another theme.
Version: 1.1
Author: GhostPool
Author URI: http://themeforest.net/user/GhostPool/portfolio?ref=GhostPool
License: You should have purchased a license from ThemeForest.net
*/

if(!class_exists('GP_Bounce')) {

	class GP_Bounce {

		public function __construct() {
		
			if(!post_type_exists('slide') && !class_exists('GP_Slide_Post')) {
				require_once(sprintf("%s/slide-post-type/slide-post-type.php", dirname(__FILE__)));
				$GP_Slide_Post = new GP_Slide_Post();
			}
						
			if(!class_exists('CustomSidebars')) {
				require_once(sprintf("%s/custom-sidebars/custom-sidebars.php", dirname(__FILE__)));
			}
						
			if(!class_exists('Widget_Importer_Exporter')) {
				require_once(sprintf("%s/widget-importer-exporter/widget-importer-exporter.php", dirname(__FILE__)));
			}
							
		} 
		
		public static function gp_activate() {} 		
		public static function gp_deactivate() {}
		
	}
	
}

if(class_exists('GP_Bounce')) {

	register_activation_hook(__FILE__, array('GP_Bounce', 'gp_activate'));
	register_deactivation_hook(__FILE__, array('GP_Bounce', 'gp_deactivate'));

	$ghostpool = new GP_Bounce();

}

?>